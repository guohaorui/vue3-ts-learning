<template>
  <div>分页器组件</div>
</template>

<script lang="ts" setup></script>

<style scoped></style>
