<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped></style>
