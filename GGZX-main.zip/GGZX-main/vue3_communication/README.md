## 完整引入element-plus
- https://element-plus.gitee.io/zh-CN/guide/quickstart.html

## 尤大建议不要省略vue扩展名
- https://github.com/vitejs/vite/issues/178#issuecomment-630138450

- npm i less less-loader

- npm i pubsub-js @types/pubsub-js

- npm i @element-plus/icons-vue