<template>
    <div>
      分页器组件
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>