<template>
    <div class="box">
        <h1>用户管理</h1>
    </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.box {
    width: 100%;
    height: 4000px;
    background: red;
}
</style>